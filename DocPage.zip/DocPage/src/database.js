const docData =[ 
	{
		description: 'Médico 1',
		doctorName: 'João da Silva',
		phoneNumber: '31-999999999',
		email: 'doc@unimed.com',
		cpf: '123.456.789-00',
		CRM: '123456/MG',
		medicalField: 'Cardiologia',
		dateOfBirth: '1992-02-25',
		gender: 'M',
		isLogged: true,

	},
	{
		description: 'Médico 2',
		doctorName: 'Carlos Henrique Oliveira',
		phoneNumber: '31-988888888',
		email: 'carlose@medsenior.com',
		cpf: '987.654.321-00',
		CRM: '654321/SP',
		medicalField: 'Neurologia',
		dateOfBirth: '1985-07-12',
		gender: 'M',
		isLogged: false,
	},
	{
		description: 'Médico 3',
		doctorName: 'Ana Paula Silva',
		phoneNumber: '31-977777777',
		email: 'ana.silva@goldencross.com',
		cpf: '321.654.987-00',
		CRM: '987654/PR',
		medicalField: 'Pediatria',
		dateOfBirth: '1990-11-30',
		gender: 'F',
		isLogged: false,
	}
];

// send the data to local storage

localStorage.setItem('doctors',JSON.stringify(docData));

